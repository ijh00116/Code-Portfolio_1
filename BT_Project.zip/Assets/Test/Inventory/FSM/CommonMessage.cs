using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Testb;

    public class ShowDialogMsg : Message
    {

    }

    public class HideDialogMsg : Message
    {

    }