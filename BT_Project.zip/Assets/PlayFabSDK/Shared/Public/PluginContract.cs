﻿namespace PlayFab
{
    public enum PluginContract
    {
        PlayFab_Serializer,
        PlayFab_Transport
    }
}